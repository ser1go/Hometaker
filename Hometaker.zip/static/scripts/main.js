// Кнопка мобильного меню


    document.getElementById('menu_button').onclick =() => {
        document.getElementById('mob_m').classList.toggle('show-menu');
    }